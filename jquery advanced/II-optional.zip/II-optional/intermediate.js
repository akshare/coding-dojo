$(document).ready(function(){

	$( "form" ).submit(function() {
		//console.log( $( this ).serializeArray() );

		var fname_data = $("#fname").val(),
		lname_data =$("#lname").val(),
		description_data = $("#description").val();

		$("#table_output_contact").append(

			"<div class='contact'><h3>" + fname_data + " " + lname_data + "</h3>" + "<p att-src-data='"+ description_data +"'>Click for description.</p></div>"

		);
			
		return false;
	});

	$(document).on('click','p', function(){

		$('#table_output_description').html("<p>" + $(this).attr('att-src-data') + "</p>").slideUp().slideDown();

		//console.log($(this).attr('att-src-data'));

	})

});