$(document).ready(function(){

	$( "form" ).submit(function() {
		//console.log( $( this ).serializeArray() );

		$("#table_output tbody").append(

			"<tr><td>" + $("#fname").val() + "</td><td>" +
			$("#lname").val() + "</td><td>" + 
			$("#email").val() + "</td><td>" +
			$("#contact").val() + "</td></tr>"

		);
			
		return false;
	});

});