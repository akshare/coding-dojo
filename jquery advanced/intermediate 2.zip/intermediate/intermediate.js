$(document).ready(function(){

	$("#registration").submit(function(){
		var serialize_form = $(":input").serializeArray();
 		
		//$("#table_output tbody").prepend("<tr>"); Does not seem to work

		$.each(serialize_form, function(i, field){
 			$("#table_output tbody").append("<td>" + field.value + "</td>");
 		});

		//$("#table_output tbody").append("</tr>"); Does not seem to work

		return false;
	});
});