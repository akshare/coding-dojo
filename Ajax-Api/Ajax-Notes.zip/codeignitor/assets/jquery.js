$(document).ready(function(){  

	// Get all notes from the database

  	$.get('/notes/get_all_notes', {}, function(notes){
  		$.each(notes, function(index, note){
  			$("#notes_display").append(note);
  		});
  	}, "json");


	// Add notes to the database on submit and append result

	$('#form_add_note').submit(function(){

		alert("ADD INITIATED!");
	    
	    $.post( 
	    	$('#form_add_note').attr('action'),
	    	$('#form_add_note').serialize(),
		    function(output){
		        $('#notes_display').append(
		        	'<div id="id_'+output.note_id+'" class="notes_box">'+
			        	'<div class="delete">'+
							'<form id="form_delete_note" action="notes/delete" method="post">'+
								'<input type="hidden" value="'+output.note_id+'" name="id">'+
								'<input type="hidden" value="delete" name="action">'+
								'<input class="delete" type="submit" value="Delete">'+
							'</form>'+
						'</div>'+
						'<div class="notes">'+output.note+'</div>'+
						'<div note_id="'+output.note_id+'" class="description">'+output.note_description+'</div>'+
					'</div>');
		    }, 'json'
		);
	    return false;
	});


	// Delete note from database and remove deleted element

	$('#notes_display').on('submit','#form_delete_note', function(){
	    
	    alert("DELETE INITIATED!");
	    
	    $.post( 
	    	$('#form_delete_note').attr('action'),
	    	$('#form_delete_note').serialize(),
	    	function(delete_note){
	        	$('#id_'+delete_note.note_id).remove();
	    	}, 'json'
	    );
	    return false;
	});


	// Edit note and save to database, return edited data from database as well.

	$('#notes_display').on('submit','#form_edit_note', function(){
	   
	    alert("EDIT INITIATED!");
	   
	    $.post( 
	    	$('#form_edit_note').attr('action'),
	    	$('#form_edit_note').serialize(),
	    	function(edit_notes){
	      		$.each(edit_notes, 
	      		function(index, note){
  					$("#notes_display").append(note);
  				});
	    	}, 'json'
	    );
	    return false;
	});


	// When description box is clicked, change the div to textarea contained within a form

	$('#notes_display').on("click",".description",function(){
		
		var note_data = $(this).html();
		var note_id = $(this).attr('note_id');
		
		$(this).replaceWith("<form id='form_edit_blur_note' action='notes/edit' method='post'><input type='hidden' value='"+ note_id +"' name='id'><textarea id='active' name='description'>"+ note_data +"</textarea></form>");
		$('#active').focus();
	});


	// When focusout of textarea, save the data to database and return the result.
	// Also change the textarea back to div

	$('#notes_display').on('focusout','textarea#active', function(){
	   
	    alert("EDIT INITIATED!");
	   
	    $.post( 
	    	$('#form_edit_blur_note').attr('action'),
	    	$('#form_edit_blur_note').serialize(),
	    	function(edit_note){
	      		console.log(edit_note);
				$('#form_edit_blur_note').replaceWith("<div note_id='"+ edit_note.note_id +"' class='description'>"+ edit_note.note_description +"</div>");
	      	}, 'json'
	    );
	    return false;
	});
  	

  	// fadeout notice

  	$('.notice').fadeOut(3000);

});