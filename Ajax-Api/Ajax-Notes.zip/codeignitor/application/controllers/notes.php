<?php

	class notes extends CI_Controller
	{
		function index()
		{
			$this->load->view('notes');
		}

		public function get_all_notes()
		{	
			$this->load->model('note');
			$notes = $this->note->display_all();
			
			$note_block = array();

			foreach($notes as $note)
			{
				$note_id = $note['id'];

				$note = '<div class="notes">'.$note['notes'].'</div><div note_id="'.$note['id'].'" class="description">'.$note['description'].'</div>';
							
				$note_block[] = '<div id="id_'. $note_id .'" class="notes_box">
									<div class="delete">
										<form id="form_delete_note" action="notes/delete" method="post">
											<input type="hidden" value="'. $note_id .'" name="id">
											<input type="hidden" value="delete" name="action">
											<input class="delete" type="submit" value="Delete">
										</form>
									</div>'. $note . 
								'</div>';
			}

			echo json_encode($note_block);
		}


		function add()
		{
			$this->load->model('note');
			$add_notes = $this->note->add($this->input->post(NULL, TRUE));
			
			$data['note'] = $add_notes['notes'];
			$data['note_description'] = $add_notes['description'];
			$data['note_id'] = $add_notes['id'];

			echo json_encode($data);
		}

		function edit()
		{
			$this->load->model('note');
			$edit_notes = $this->note->edit($this->input->post(NULL, TRUE));
			
			$data['note_id'] = $edit_notes['id'];
			$data['note_description'] = $edit_notes['description'];

			echo json_encode($data);
		}

		function delete()
		{
			$this->load->model('note');
			$delete_notes = $this->note->delete($this->input->post('id'));

			$data['note_id'] = $this->input->post('id');

			echo json_encode($data);
		}
	}

?>