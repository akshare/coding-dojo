<html>
	<head>
		<title>AJAX - post, edit, delete</title>

		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
		<link rel="stylesheet" type="text/css" href="/assets/style.css">
 		<script src="/assets/jquery.js"></script> 
	</head>
	<body>
		<div id="wrapper">
			<div id="notes_display">
				<!-- Jquery data -->			
			</div>
			<div id="form">
				<form id="form_add_note" action="notes/add" method="post">
					<p><input type="text" name="note" placeholder="Title"></p>
					<p><textarea name="description" placeholder="Description"></textarea></p>
					<input type="hidden" value="add_note" name="action">
					<p><input type="submit" value="submit"></p>
				</form>
			</div>
		</div>
	</body>
<html>