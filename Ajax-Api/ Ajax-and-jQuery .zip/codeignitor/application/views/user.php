<html>
	<head>
		<title>TEST AJAX</title>
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
		<script>
		  $(document).ready(function(){
		   $('#mainForm').submit(function(){
		    $.post( 
		      $('#mainForm').attr('action'),
		      $('#mainForm').serialize(),
		      function(output){
		        $('#user_data').append("name: "+output.name+ " age: "+output.age+ "<br />");
		      }, "json"
		    );
		    return false;
		   });
		  });
		</script>
	</head>
	<body>
		<?= $notice; ?>
		<form id="mainForm" action="users/random" method="post">
			<input type="hidden" name="action" value="load_random_user">
			<input type="submit" value="Via Ajax, grab information of random person">
		</form>
		<div id="user_data"></div>
	</body>
</html>