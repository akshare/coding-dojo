<?php

	class Users extends CI_Controller
	{
		function index()
		{
			if($this->session->userdata('json_data')){
				$message['json_data'] = $this->session->userdata('json_data');
				//var_dump($message);
			}
			else{
				$message['json_data'] = "FALSE";
			}

			if($this->session->flashdata('notice') === TRUE){
				$message['notice'] = $this->session->flashdata('notice');
			}
			else{
				$message['notice'] = "";
			}

			$this->load->view('user', $message);
		}

		function random()
		{
			if($this->input->post('action') === "load_random_user"){
				$names = array('John', 'Michael', 'Joe', 'Trey');
				$output = array("name" => $names[rand(0,count($names)-1)], "age" => rand(18,60));
				echo json_encode($output);
				//$this->session->set_userdata('json_data', json_encode($output));
				//redirect(base_url('/'));
			}
			else
			{	
				$this->session->set_flashdata('notice', 'You must click the button');
				redirect(base_url('/'));
			}
		}
	}

?>