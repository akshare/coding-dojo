<html>
	<head>
		<title>Ajax exercise - Ajax Posts</title>
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
		
		<script>
		  $(document).ready(function(){  

			$('#form_notes').submit(function(){
			    $.post( 
			      $('#form_notes').attr('action'),
			      $('#form_notes').serialize(),
			      function(output){
			      	console.log(output);
			        $('#note_display').append("<div class='notes_box'>"+output.note+"<br/><a href=notes/delete_note/"+output.note_id+">delete</a></div>");
			      }, "json"
			    );
			    return false;
			});

			/*$('#note_display').on("click",".notes_box",function(){
				var note_data = $(this).html();
				$(this).replaceWith("<textarea id='active'>"+ note_data +"</textarea>");
				$('#active').focus();
			});

			$('#note_display').on("focusout","textarea",function(){
				var note_data = $(this).html();
				$(this).replaceWith("<div class='notes_box'>"+ note_data +"</div>");
			});*/
		  	
		  	$('.notice').fadeOut(3000);

		  });
		</script>
		

		<style>
			#note_display{
				
			}
			.notes_box, textarea{
				border: solid 1px #cccccc;
				width: 200px;
				height: 100px;
				margin: 10px;
				float: left;
			}

			#post_it{
				float: none;
			}
		</style>
	</head>
	<body>
		<div id="note_display">
			<?php
			/*
				if($notice){
					echo '<p class="notice">'. $notice . '</p>';
				}
				else
				{

				}

				$notes_wrapper = NULL;
				foreach($notes_data as $key => $value){
					$notes_value = NULL;
					foreach($value as $sub_key => $sub_value){
						$notes_value .= $sub_value . "<br/>";
					}
					$notes_wrapper .= '<div class="notes_box">'. $notes_value . '</div>';
				}
				echo $notes_wrapper;
			*/
			?>
		</div>
		<div style="clear:both;"></div>
		<form id="form_notes" action="notes/add_note" method="post">
			<p><textarea id="post_it" name="note"></textarea></p>
			<p><input type="submit" value="Post It!"></p>
		</form>
	</body>
</html>