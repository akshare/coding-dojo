<?php
	class notes extends CI_Controller
	{
		function index()
		{
			if($this->session->flashdata('notice')){
				$notes['notice'] = $this->session->flashdata('notice');
			}
			else{
				$notes['notice'] = '';
			}

			$this->load->model('note');
			$notes['notes_data'] = $this->note->display_notes();

			if($notes){
				$notes['notes_data'] = $this->note->display_notes();
				//echo json_encode($notes);
			}
			else
			{
				$notes['notes_data'] = 'No notes...';
			}
			
			$this->load->view('notes', $notes);
		}

		function delete_note($note_id){
			$this->load->model('note');

			$delete_note = $this->note->delete_note($note_id);

			echo json_encode(array('note'=>'deleted','note_id'=>$note_id));

		}

		function add_note()
		{
			$this->load->model('note');
			
			$add_notes = $this->note->add_note($this->input->post('note'));

			if($add_notes)
			{
				$data['note'] = $add_notes['notes'];
				$data['note_id'] = $add_notes['id'];

				echo json_encode($data);
				//echo json_encode($add_notes);
				//redirect to index with success session message
				//$this->session->set_flashdata('notice', 'Note has been added');
				//redirect(base_url('/'));
			}
			else
			{
				$this->session->set_flashdata('notice', 'Note was not added');
				redirect(base_url('/'));
			}
		}

	}
?>