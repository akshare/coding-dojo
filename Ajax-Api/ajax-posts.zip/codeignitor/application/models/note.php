<?php
	class note extends CI_Model
	{
		function display_notes()
		{
			$query = "SELECT * FROM notes";
			return $this->db->query($query)->result_array();
		}

		function delete_note($note_id)
		{
			$query = "DELETE FROM notes WHERE id = ?";
			$values = $note_id;

			$this->db->query($query, $values);
		}

		function display_note($note_id)
		{
			$query = "SELECT id, notes FROM notes WHERE id = $note_id";
			return $this->db->query($query)->row_array();
		}

		function add_note($note)
		{
			$query = "INSERT INTO notes (notes, created_at, updated_at) VALUES (?,?,?)";
			$values = array($note, date("Y-m-d, H:i:s"), date("Y-m-d, H:i:s"));
				
			$this->db->query($query, $values);

			$display = $this->display_note($this->db->insert_id());

			return $display;
		}
	}
?>