<?php
	$name = array([first_name][Ahmed], [last_name][Khan]);
	echo $name[0][first_name];
?>