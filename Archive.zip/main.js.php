var x=2*2;
alert("The multiplication of 2 * 2 is: " + x);