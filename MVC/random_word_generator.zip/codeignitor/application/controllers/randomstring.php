<?php
	class RandomString extends CI_Controller
	{
		function index()
		{
			//validate post data

			//if validation is good

				//check if session data counter exists
				if($this->session->userdata('counter'))
				{
					//if session data counter exists add 1 to counter
					$counter = $this->session->userdata('counter');
					
					if($counter >= 5)
					{
						$this->session->set_userdata('counter', 1);
					}
					else
					{
						$this->session->set_userdata('counter', $counter + 1);
					}
				}
				else
				{
					//else set session data counter to 1
					$this->session->set_userdata('counter', 1);
				}
				
				//generate random string & set as session
				$this->session->set_userdata('random_string', $this->generateRandomString());
				
				//set counter
				$counter = $this->session->userdata('counter');

				//merge random string + counter into multidimentional associate array
				$this->session->set_userdata('display', array('random_string' => $this->session->userdata('random_string'), 'counter' => $counter));

				$data['display'] = $this->session->userdata('display');
				$this->load->view('randomstring', $data);

				//else redirect to randomstring view with error
		}

		function generateRandomString($length = 10) {
		    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		    $charactersLength = strlen($characters);
		    $randomString = '';
		    for ($i = 0; $i < $length; $i++) {
		        $randomString .= $characters[rand(0, $charactersLength - 1)];
		    }
		    return $randomString;
		}
	}
?>