<html>
	<head>
		<title>TEST</title>
	</head>
	<body>
		<p>Random word (attempt # <?= $display['counter']; ?>)</p>
		<p><?= $display['random_string']; ?></p>
		<form action="randomstring">
			<input type="hidden" name="action" value="generate">
			<input type="submit" value="Generate">
		</form>
	</body>
</html>