<html>
	<head>
		<title>TEST</title>
		<link rel="stylesheet" type="text/css" href="assets/css/style.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
		<script src="assets/jquery/jquery.js" type="text/javascript"></script>
	</head>
	<body>
		<div id="wrapper">
			<div class="notice">
				<?php echo $results['notice']; ?>
			</div>
			<div id="course_manager">
				<h3>Add a new course</h3>
				<div class="form">
					<form action="courses/add" method="post">
						<label>Name:</label><input type="text" name="name"><br />
						<label>Description:</label><textarea name="description"></textarea>
						<input type="hidden" name="action" value="add_course">
						<label>&nbsp;</label><input type="submit" value="Add">
					</form>
				</div>
			</div>
			<div class="course_display">
				<h3>Courses</h3>
				<table cellspacing="0" cellpadding="0">
					<?php 
						foreach($results['courses'] as $key => $value)
						{
							echo "<tr>";
							foreach($value as $sub_key => $sub_value){
								echo "<td>" . $sub_value . "</td>";
							}
							echo "<td><a href='courses/delete/". $results['courses'][$key]['id'] ."/delete_course'>delete</a></td></tr>";
						}
					?>
				</table>
			</div>
		</div>
	</body>
</html>