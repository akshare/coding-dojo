<?php
	class Courses extends CI_Controller
	{
		function index()
		{
			if($this->session->flashdata('notice') !== NULL){
				$notice = $this->session->flashdata('notice');
			}
			else{
				$notice = '';
			}

			$this->output->enable_profiler(TRUE);
			
			$this->load->model("Course");
			
			$course_display['results'] = array(
				'courses' => $this->Course->get_all_courses(),
				'notice' => $notice
				);
			
			$this->load->view('courses', $course_display);
		}

		function add()
		{
			$this->load->model("Course");
			
			$course_details = array(
				'name' => $this->input->post('name'),
				'description' => $this->input->post('description')
				);
			
			if(($this->input->post('action') == "add_course") && (strlen($this->input->post('name'))) >= 15){
				$add_course = $this->Course->add_course($course_details);
				if($add_course = TRUE){
					$this->session->set_flashdata('notice', 'Course added successfully!');
					redirect(base_url('/'));
				}
			}
			else{
				$this->session->set_flashdata('notice', 'Please enter a course name longer than 15 characters');
				redirect(base_url('/'));
			}
		}

		function delete($id, $action)
		{
			$this->load->model("Course");

			if($action == "delete_course")
			{
				$delete_course = $this->Course->delete_course($id);
				if($delete_course = TRUE){
					$this->session->set_flashdata('notice', 'Course with ID "'. $id .'" deleted successfully!');
					redirect(base_url('/'));
				}
			}
			else{
				$this->session->set_flashdata('notice', 'Direct access not permitted.');
				redirect(base_url('/'));
			}
		}
	}
?>