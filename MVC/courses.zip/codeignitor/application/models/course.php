<?php
	class Course extends CI_Model
	{
		function get_all_courses()
		{
			$query = "SELECT * FROM courses ORDER BY date_added ASC";
			return $this->db->query($query)->result_array();
		}

		function add_course($course)
		{
			$query = "INSERT INTO courses (name, description, date_added) VALUES (?,?,?)";
			$values = array($course['name'], $course['description'], date("Y-m-d, H:i:s"));
			return $this->db->query($query, $values);
		}

		function delete_course($course_id)
		{
			$query = "DELETE FROM courses WHERE id = ?";
			$values = $course_id;
			return $this->db->query($query, $values);
		}
	}
?>