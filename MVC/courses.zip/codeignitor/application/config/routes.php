<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$route['default_controller'] = "Courses";
$route['success'] = "Courses/success";
$route['error'] = "Courses/error";
$route['404_override'] = '';

//end of routes.php