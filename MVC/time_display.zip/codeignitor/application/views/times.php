<?php
	echo '<div align="center"><p>The current date and time</p>' . $date . '<br/>' . $time . '</div>';
?>