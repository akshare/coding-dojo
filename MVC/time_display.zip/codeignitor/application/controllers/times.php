<?php

class Times extends CI_Controller
{
	public function main()
	{
		$date_time = array(
			'date' => date('M j, Y'),
			'time' => date('g:i A')
			);
		$this->load->view('times', $date_time);
	}
}

?>