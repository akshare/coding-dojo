$('document').ready(function(){
	$('.notice').fadeOut(5000);
});