<?php

class Surveys extends CI_Controller
{
	function index()
	{
		//load form view
		$this->load->helper(array('form', 'url'));

		$this->load->library('form_validation');

		$this->load->view('survey');
	}

	function process()
	{	
		//check if session counter exists, if exist add +1, if not, set the counter to 1
		if($this->session->userdata('counter'))
		{
			$counter = $this->session->userdata('counter');
			$this->session->set_userdata('counter', $counter + 1);
			
			if($counter >= 5){
				$this->session->set_userdata('counter', 1);
			}
		}
		else{
			$this->session->set_userdata('counter', 1);
		}
		
		/*if($post = TRUE && $post['action'] == "submit_survey")
		{
			redirect(base_url('/result'));
		}
		else{
			redirect('/survey');
		}*/

		$this->load->helper(array('form', 'url'));

		$this->load->library('form_validation');

		$validate = array(
               array(
                     'field'   => 'name',
                     'label'   => 'Name',
                     'rules'   => 'required'
                  ),
               array(
                     'field'   => 'location',
                     'label'   => 'Location',
                     'rules'   => 'required'
                  ),
               array(
                     'field'   => 'favorite_language',
                     'label'   => 'Favorite Language',
                     'rules'   => 'required'
                  ),   
               array(
                     'field'   => 'comment',
                     'label'   => 'Comment',
                     'rules'   => 'required'
                  )
            );

		$this->form_validation->set_rules($validate); 

		if ($this->form_validation->run() == FALSE)
		{
			redirect(base_url('/surveys'));		
		}
		else
		{
			//post data + session data into associative array and load success view
			$post = $this->input->post(NULL, TRUE);
			$counter = array('session_counter' => $this->session->userdata('counter'));		
		
			$this->session->set_userdata('result', array('post_data' => $post, 'counter' => $counter));
			
			redirect(base_url('/result'));
		}

	}

	function result()
	{
		$view_data['post'] = $this->session->userdata('result');
		$this->load->view('success', $view_data);
	}
}

?>