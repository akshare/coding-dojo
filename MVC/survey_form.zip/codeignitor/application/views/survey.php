<?php echo validation_errors(); ?>

<form action="surveys/process" method="post">
	<p>Your Name: <input type="text" name="name" value="<?php echo set_value('name'); ?>"></p>
	<p>
		Dojo Location: 
		<select name="location">
			<option value="" <?php echo set_select('location', '', TRUE); ?>>please select</option>
			<option value="San Diego" <?php echo set_select('location', 'San Diego'); ?>>San Diego</option>
			<option value="Seattle" <?php echo set_select('location', 'Seattle'); ?>>Seattle</option>
			<option value="Los Angeles" <?php echo set_select('location', 'Los Angeles'); ?>>Los Angeles</option>
		</select>
	</p>
	<p>
		Favorite Language: 
		<select name="favorite_language">
			<option value="" <?php echo set_select('favorite_language', '', TRUE); ?>>please select</option>
			<option value="PHP" <?php echo set_select('favorite_language', 'PHP'); ?>>PHP</option>
			<option value="Javascript" <?php echo set_select('favorite_language', 'Javascript'); ?>>Javascript</option>
			<option value="Jquery" <?php echo set_select('favorite_language', 'Jquery'); ?>>Jquery</option>
		</select>
	</p>
	<p>
		Comment: <textarea name="comment"><?php echo set_value('comment'); ?></textarea>
	</p>
	<p>
		<input type="hidden" name="action" value="submit_survey">
		<input type="submit" value="Submit">
	</p>
</form>