<?php $this->load->view('header') ?>
	<p>
		Thanks for submitting this form! You have submitted this form <?php echo $post['counter']['session_counter']; ?> times now.
	</p>
	<p>
		Name: <?php echo $post['post_data']['name']; ?> <br/>
		Location: <?php echo $post['post_data']['location']; ?> <br/>
		Favorite Language: <?php echo $post['post_data']['favorite_language']; ?> <br/>
		Comment: <?php echo $post['post_data']['comment']; ?> <br/>
	</p>
<?php $this->load->view('footer') ?>