<?php
	class ninja_gold_game extends CI_Controller
	{
		function index()
		{
			$session_data['ninja_data'] = $this->session->all_userdata();
						
			if($this->session->userdata('session_points_total')){
				$this->load->view('ninja_gold_game', $session_data);
			}
			else{
				$session_data['ninja_data'] = $this->session->set_userdata('session_points_total', 0);
				$session_data['ninja_data'] = $this->session->set_userdata('log_activity', 'No activity');
				$this->load->view('ninja_gold_game', $session_data);
			}
		}

		function process_money()
		{
			//post
			$building = $this->input->post('building');
			
			//if farm
			if($building == "farm")
			{
				$points = $this->random_points(10,20);
				$date_time = $this->date_time();
			}
			
			//if cave
			elseif($building == "cave")
			{
				$points = $this->random_points(5,10);
				$date_time = $this->date_time();
			}

			//if house
			elseif($building == "house")
			{
				$points = $this->random_points(2,5);
				$date_time = $this->date_time();
			}

			//if casino
			elseif($building == "casino")
			{
				$points = $this->random_points(-50,50);
				$date_time = $this->date_time();
			}

			if($points < 0){
				$log_activity = NULL;
				$log_activity = $this->session->userdata('log_activity') . "<p>Entered a Casino and lost $points golds from the $building! $date_time</p>";
			}
			else{
				$log_activity = NULL;
				$log_activity = $this->session->userdata('log_activity') . "<p>Earned $points golds from the $building! $date_time</p>";
			}

			//if session points set
			if($building)
			{
				//set session + points + date
				$this->session->set_userdata('session_points_total', $this->session->userdata('session_points_total') + $points);
				$this->session->set_userdata('log_activity', $log_activity);
			}
			else
			{
				//set session with points + date
				$this->session->set_userdata('log_activity', $log_activity);
			}

			redirect(base_url('/'));

		}

		function date_time()
		{
			$date_time = date('M jS Y - g:i a');
			return $date_time;
		}

		function random_points($start_points, $end_points)
		{
			$random_points = rand($start_points, $end_points);
			return $random_points;
		}

		function reset_session()
		{
			$this->session->sess_destroy();
			redirect(base_url('/'));
		}
	}
?>