<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$route['default_controller'] = "ninja_gold_game";
$route['process_money'] = "ninja_gold_game/process_money";
$route['reset_session'] = "ninja_gold_game/reset_session";
$route['404_override'] = '';

//end of routes.php