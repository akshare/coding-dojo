<html>
	<head>
		<title>TEST</title>
		 <link rel="stylesheet" type="text/css" href="/assets/css/main.css">
	</head>
	<body>
		<form action="reset_session" method="post">
			<input type="submit" value="Reset!">
		</form>
		<div id="wrapper">
			<div id="current-gold-points">
				Your Gold: <?= $ninja_data['session_points_total']; ?>
			</div>
			<div id="farm">
				<h3>Farm</h3>
				<p>(earns 10-20 gold)</p>
				<form action="ninja_gold_game/process_money" method="post">
					<input type="hidden" name="building" value="farm">
					<input type="submit" value="Find Gold!">
				</form>
			</div>
			<div id="cave">
				<h3>Cave</h3>
				<p>(earns 5-10 gold)</p>
				<form action="process_money" method="post">
					<input type="hidden" name="building" value="cave">
					<input type="submit" value="Find Gold!">
				</form>
			</div>
			<div id="house">
				<h3>House</h3>
				<p>(earns 2-5 gold)</p>
				<form action="process_money" method="post">
					<input type="hidden" name="building" value="house">
					<input type="submit" value="Find Gold!">
				</form>
			</div>
			<div id="casino">
				<h3>Casino</h3>
				<p>(earns/takes 0-50 gold)</p>
				<form action="process_money" method="post">
					<input type="hidden" name="building" value="casino">
					<input type="submit" value="Find Gold!">
				</form>
			</div>
			<div id="activities">
				<h3>Activities:</h3>
				<?= $ninja_data['log_activity']; ?>
			</div>
		</div>
	</body>
</html>